package ficha04.V2Ex1;

public class Reptil extends Animal {
}
