package ficha04.Ex2;

public class ExpumaDeLeite extends Leite{
    public ExpumaDeLeite() {
        this.nome = "expuma de leite";
        this.temperatura = 60;
        this.quantidade = 80;
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
