package ficha04.Ex2;

public class Coffee extends Drink{

    public Coffee() {
        super("café", 60, 100);
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
