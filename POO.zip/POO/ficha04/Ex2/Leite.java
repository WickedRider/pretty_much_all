package ficha04.Ex2;

public class Leite extends Drink{
    public Leite() {
        super("leite", 55, 150);
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
